const pageContent = document.getElementById("pageContent");
const pageTitle = document.getElementById("pageTitle");

const pages = {
  Dashboard: `
    <div class="cards">
      <div class="card">
        <p>Total Customers</p>
        <h2>120</h2>
      </div>

      <div class="card">
        <p>Active Subscriptions</p>
        <h2>85</h2>
      </div>

      <div class="card">
        <p>Total Revenue</p>
        <h2>₹45,000</h2>
      </div>

      <div class="card">
        <p>Pending Invoices</p>
        <h2>12</h2>
      </div>
    </div>

    <div class="welcome">
      <h2>Subscription Management</h2>
      <p>Manage your customers, products and subscriptions in one place.</p>
      <button onclick="showPage('Customers')">View Customers</button>
    </div>
  `,

  Customers: `
    <div class="welcome">
      <h2>Customer Management</h2>
      <p>Add and manage your customers.</p>

      <input id="customerName" placeholder="Customer name">
      <input id="customerEmail" placeholder="Email address">
      <button onclick="addCustomer()">Add Customer</button>
    </div>

    <div class="card table-card">
      <h2>Customer List</h2>
      <div id="customerList"></div>
    </div>
  `,

  Products: `
    <div class="welcome">
      <h2>Products</h2>
      <p>Manage the products offered by Brightloop.</p>
      <button onclick="alert('Product creation coming soon!')">+ Add Product</button>
    </div>
  `,

  Subscriptions: `
    <div class="welcome">
      <h2>Subscriptions</h2>
      <p>Track customer subscription plans and their status.</p>
      <button onclick="alert('Subscription creation coming soon!')">+ New Subscription</button>
    </div>
  `,

  Invoices: `
    <div class="welcome">
      <h2>Invoices</h2>
      <p>View and manage customer invoices.</p>
      <button onclick="alert('Invoice creation coming soon!')">+ Create Invoice</button>
    </div>
  `,

  Payments: `
    <div class="welcome">
      <h2>Payments</h2>
      <p>Monitor payment records and transactions.</p>
    </div>
  `,

  Reports: `
    <div class="welcome">
      <h2>Reports & Analytics</h2>
      <p>View your business performance and subscription statistics.</p>
    </div>
  `
};

let customers = [];

function showPage(page) {
  pageTitle.textContent = page;
  pageContent.innerHTML = pages[page];

  document.querySelectorAll("nav button").forEach(button => {
    button.classList.toggle(
      "active",
      button.dataset.page === page
    );
  });

  if (page === "Customers") {
    displayCustomers();
  }
}

function addCustomer() {
  const name = document.getElementById("customerName").value.trim();
  const email = document.getElementById("customerEmail").value.trim();

  if (!name || !email) {
    alert("Please enter both name and email!");
    return;
  }

  customers.push({ name, email });

  displayCustomers();

  document.getElementById("customerName").value = "";
  document.getElementById("customerEmail").value = "";

  alert("Customer added successfully!");
}

function displayCustomers() {
  const list = document.getElementById("customerList");

  if (customers.length === 0) {
    list.innerHTML = "<p>No customers added yet.</p>";
    return;
  }

  list.innerHTML = customers.map((customer, index) => `
    <p class="customer-row">
      ${index + 1}. <strong>${customer.name}</strong>
      — ${customer.email}
    </p>
  `).join("");
}

document.querySelectorAll("nav button").forEach(button => {
  button.addEventListener("click", () => {
    showPage(button.dataset.page);
  });
});

showPage("Dashboard");
let customerList = [];

function addNewCustomer() {
  const name = document.getElementById("newCustomer").value.trim();
  const email = document.getElementById("newEmail").value.trim();

  if (!name || !email) {
    alert("Please enter both name and email!");
    return;
  }

  customerList.push({ name, email });

  document.getElementById("customerDisplay").innerHTML =
    customerList.map(customer => `
      <div class="card">
        <h3>${customer.name}</h3>
        <p>${customer.email}</p>
      </div>
    `).join("");

  document.getElementById("newCustomer").value = "";
  document.getElementById("newEmail").value = "";
}